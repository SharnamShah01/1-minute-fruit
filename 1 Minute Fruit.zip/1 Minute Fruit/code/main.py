
import json
from pickle import TRUE
from pygame import K_ESCAPE, K_RETURN, K_SPACE, KEYDOWN
from setting import *
from sprites import *


class Game:
    def __init__(self):
        pygame.init()
        pygame.display.set_mode((WIN_WIDTH,WIN_HEIGHT))
        self.display_surface = pygame.display.get_surface()
        pygame.display.set_caption('1 minute Fruit')
        self.clock = pygame.time.Clock()
        self.running = False
        self.game_end = False

        self.game_sound = pygame.mixer.Sound(join('audio', 'game_audio.mp3'))
        self.game_sound.set_volume(1)
        self.game_sound.play(loops = -1)


        # sprite groups
        self.all_sprites = pygame.sprite.Group()
        self.collsion_sprite = pygame.sprite.Group()
        self.fruit_sprites = pygame.sprite.Group()

        self.player = PlayerSprirte(PLAYER_SPAWN_PLACE,self.all_sprites,self.collsion_sprite)
        
        # map
        self.empty_places = []
        self.create_map(self.all_sprites,self.collsion_sprite)

        # fruits
        self.fruit_spwan = True
        

        # score
        self.score = 0
        self.font = pygame.font.Font(join('Fonts','Cakecafe.ttf'),50)
        try:
            with open(join('Data', 'highsore.txt')) as score_file:
                self.high_score = json.load(score_file)
        except:
            self.high_score = 0

        # game timer
        self.game_start_time = pygame.time.get_ticks()
        self.time_limit = 60
        
  
    def create_fruits(self):
        Fruit(self.empty_places, (self.all_sprites, self.fruit_sprites))
        self.fruit_spwan = False

    def collide_with_fruit(self):
        
            if pygame.sprite.spritecollide(self.player,self.fruit_sprites,True,pygame.sprite.collide_mask):
                self.score += 1;
                eat_sound = pygame.mixer.Sound(join('audio','eat_fruit.mp3'))
                eat_sound.play()
                eat_sound.set_volume(0.1)
                self.fruit_spwan = True

    def display_score(self):
        score_font = pygame.font.Font(join('Fonts','Cakecafe.ttf'),40)
        self.score_surf = score_font.render(f"Score: {str(self.score)}",True,FONT_COLOR)
        self.score_rect = self.score_surf.get_frect(center = (WIN_WIDTH-120,WIN_HEIGHT-50))
        self.display_surface.blit(self.score_surf,self.score_rect)     
    
    def display_time_left(self):
        elapsed_time = (pygame.time.get_ticks() - self.game_start_time -1)//1000
        time_left = max(60 - elapsed_time,0)

        display_font_font = pygame.font.Font(join('Fonts','Dinofiles.ttf'),35)
        display_font = display_font_font.render(f"Time left: {str(time_left)}",True,FONT_COLOR)
        font_rect = display_font.get_frect(center = (WIN_WIDTH-120,WIN_HEIGHT - 100))

        self.display_surface.blit(display_font,font_rect)


        if(time_left <= 0):
            self.game_sound.stop()
            self.high_score = max(self.score,self.high_score)
            with open(join('data', 'highsore.txt'),'w') as score_file:
                            json.dump(self.high_score,score_file)

            self.end_sound = pygame.mixer.Sound(join('audio','game_end.mp3'))
            self.end_sound.play()

            self.game_end = True
            
    def display_high_score(self):
        
        self.highscore_surf = self.font.render(f"HIGH SCORE: {str(self.high_score)}",True,HIGH_SCORE_COLOR)
        self.highcore_rect = self.highscore_surf.get_frect(center = (WIN_WIDTH/2,WIN_HEIGHT/2 - 200))

        self.display_surface.blit(self.highscore_surf,self.highcore_rect)

    def create_map(self,all_sprites, collision_sprites):
        map_data = [
                     [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
                     [1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,1],
                     [1,1,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,1],
                     [1,1,0,0,0,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1],
                     [1,1,1,1,1,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1],
                     [1,1,1,1,1,0,0,1,1,0,0,1,1,0,0,0,1,0,0,1],
                     [1,1,1,1,1,0,0,1,1,0,0,1,1,0,0,0,1,0,0,1],
                     [1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,1,0,0,1],
                     [1,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,1],
                     [1,1,1,0,0,1,1,1,0,0,0,0,1,0,0,0,1,0,0,1],
                     [1,1,1,0,0,1,1,1,0,0,0,0,1,0,0,0,1,0,0,1],
                     [1,1,1,0,0,1,1,1,1,1,1,1,1,1,0,0,1,0,0,1],
                     [1,1,1,0,0,1,1,1,1,1,1,1,1,1,0,0,1,0,0,1],
                     [1,1,1,0,0,1,1,1,1,1,1,1,0,0,0,0,0,0,0,1],
                     [1,1,1,0,0,1,1,1,1,1,1,1,0,0,0,0,0,0,0,1],
                     [1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
                     [1,1,1,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1],
                     [1,1,1,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1],
                     [1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1],
                     [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
        ]

       
        tile_size = 30
        for row_index, row in enumerate(map_data):
            for col_index, tile in enumerate(row):
                if tile == 1:
                    pos = (col_index * tile_size, row_index * tile_size)
                    size = (tile_size, tile_size)
                    Obstacle(pos, size, (all_sprites, collision_sprites))
                elif tile == 0:
                    self.empty_places.append((col_index*tile_size,row_index*tile_size))

    def game_end_screen(self):
        end = True
        
        while end:

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    end = False
                    pygame.quit()

                if event.type == KEYDOWN:
                    if event.key == K_RETURN:
                        end = False
                        with open(join('data', 'highsore.txt'),'w') as score_file:
                            json.dump(self.high_score,score_file)
                        self.reset_game()

                    if event.key == K_ESCAPE:
                        end=False        
                        pygame.quit()
                        quit()

            self.display_surface.fill(GAME_END_SCREEN_COLOR)

            time_over_score_font = pygame.font.Font(None,50)
            self.end_screen_surf = time_over_score_font.render(f"Time Over Your Score: {self.score}",True,TIME_OVER_SCORE_COLOR)
            self.end_screen_rect = self.end_screen_surf.get_frect(center = (WIN_WIDTH/2,150))
            self.display_surface.blit(self.end_screen_surf,self.end_screen_rect)

            instruction_font = pygame.font.Font(join('Fonts','Cakecafe.ttf'),30)

            self.instruction_text = instruction_font.render("To Restart press ENTER",True,GAME_END_SCREEN_TEXT_COLOR)
            self.instruction_text_rect = self.instruction_text.get_frect(center = (WIN_WIDTH/2,WIN_HEIGHT/2+100))
            self.display_surface.blit(self.instruction_text,self.instruction_text_rect)

            self.intrustion2_text = instruction_font.render("To exit the game press ESCAPE",True,GAME_END_SCREEN_TEXT_COLOR)
            self.instrucyion2_text_rect = self.intrustion2_text.get_frect(center = (WIN_WIDTH/2,WIN_HEIGHT/2+200))
            self.display_surface.blit(self.intrustion2_text,self.instrucyion2_text_rect)


            pygame.display.update()

    def reset_game(self):
        self.__init__()
        
        self.run()

    def home_screen(self):

        glump_image = pygame.image.load(join('images','player', 'move', '0.png.png')).convert_alpha()
        glump_image = pygame.transform.rotozoom(glump_image,0,3)
        glump_rect = glump_image.get_frect(bottomright = (WIN_WIDTH/2,WIN_HEIGHT))
        glump_direction =1
        frame =0;

        # game title font
        game_title_font = pygame.font.Font(join('Fonts','Cakecafe.ttf'),80)
        instruction_font = pygame.font.Font(join('Fonts','Cakecafe.ttf'),40)

        while not self.running:
            # dt
            dt = self.clock.tick()/1000
            
            for event in pygame.event.get():
                keys = pygame.key.get_pressed()
                if event.type == pygame.QUIT:
                    self.running = False
                    pygame.quit()

                if keys[pygame.K_SPACE]:
                    self.running = True
                    self.run()


            self.display_surface.fill(HOME_SCREEN_COLOR)
            self.game_title = game_title_font.render("1 Minute fruit",True,GAME_TITLE_COLLOR)
            self.game_title_rect = self.game_title.get_frect(center = (WIN_WIDTH/2, WIN_HEIGHT/2 - 100))
            self.display_surface.blit(self.game_title,self.game_title_rect)

            self.text = instruction_font.render("Pess Space to Start Game", True,GAME_TEXT_COLOR)
            self.text_rect = self.text.get_frect(center = (WIN_WIDTH/2, WIN_HEIGHT/2))
            self.display_surface.blit(self.text,self.text_rect)

            self.game_move_font = pygame.font.Font(None,40)
            self.game_movement_surf = self.game_move_font.render('W or Up arrow : Up\nA or Left arrow: Left\nS or Down arrow: Down\nD or Right arrow: Right',True,GAME_TEXT_COLOR)
            self.gaem_move_rect = self.game_movement_surf.get_frect(center = (WIN_WIDTH/2,WIN_HEIGHT/2+150))
            self.display_surface.blit(self.game_movement_surf,self.gaem_move_rect)

            glump_rect.x += glump_direction*PLAYER_SPEED*dt
            if(glump_rect.right > WIN_WIDTH):
                glump_direction *= -1
                glump_rect.right = WIN_WIDTH

            if(glump_rect.left < 0):
                glump_direction *= -1
                glump_rect.left = 0

            frame += 0.007
            glump_image = pygame.image.load(join('images','player', 'move', f'{int(frame % 3)}.png.png')).convert_alpha()
            glump_image = pygame.transform.rotozoom(glump_image,0,3)
            self.display_surface.blit(glump_image,glump_rect)

            self.display_high_score()



            pygame.display.update() 


    def run(self):
        
        while self.running:
            # dt
            dt = self.clock.tick()/1000
            
            # event loop
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                    pygame.quit()


                if self.fruit_spwan == True:
                    self.create_fruits()

                if self.game_end == True:
                    self.running = False
                    self.game_end_screen()
    

                    

            
            # update
            self.all_sprites.update(dt)
            self.collide_with_fruit()

            

            # draw
            self.display_surface.fill(IN_GAME_BG)
            self.all_sprites.draw(self.display_surface)
            self.display_score()
            self.display_time_left()
            pygame.display.update() 



if __name__ == '__main__':
    game = Game()
    game.home_screen()

















    # 1,1,1,1,1,1,1,1,1,1
    # 1,0,1,1,1,0,0,0,0,1
    # 1,0,1,1,1,0,1,1,1,1
    # 1,0,1,1,1,0,0,0,0,1
    # 1,0,1,0,0,0,1,1,0,1
    # 1,0,1,1,1,0,1,1,1,1
    # 1,0,0,0,0,0,0,0,0,1
    # 1,0,1,1,1,0,1,1,1,1
    # 1,0,1,1,1,0,1,1,1,1
    # 1,1,1,1,1,1,1,1,1,1

    #  [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    #  [1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,1],
    #  [1,1,1,1,1,0,1,1,1,0,1,1,1,1,1,1,1,1,0,1],
    #  [1,1,0,0,0,0,1,1,1,0,1,1,1,0,1,1,1,1,0,1],
    #  [1,1,1,1,1,0,1,1,1,0,1,1,1,0,1,1,1,1,0,1],
    #  [1,1,1,1,1,0,1,1,1,0,1,1,1,0,0,0,1,1,0,1],
    #  [1,1,1,1,1,0,1,1,1,0,1,1,1,0,1,1,1,1,0,1],
    #  [1,0,0,0,0,0,0,0,0,0,1,1,1,0,1,1,1,1,0,1],
    #  [1,1,1,0,1,1,1,1,0,0,0,1,1,0,1,1,1,1,0,1],
    #  [1,1,1,0,1,1,1,1,0,0,0,1,1,0,0,1,1,1,0,1],
    #  [1,1,1,0,1,1,1,1,0,0,0,1,1,1,0,1,1,1,0,1],
    #  [1,1,1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,1,0,1],
    #  [1,1,1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,1,0,1],
    #  [1,1,1,0,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,1],
    #  [1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1],
    #  [1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    #  [1,1,1,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1],
    #  [1,1,1,0,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1],
    #  [1,1,1,1,1,1,1,1,1,,1,1,1,1,1,1,1,1,1,1],
    #  [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    